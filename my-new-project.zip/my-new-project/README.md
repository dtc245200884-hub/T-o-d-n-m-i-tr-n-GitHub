# My New Project

## Mục tiêu
Thực hành tạo Local Repository và đồng bộ với Remote Repository trên GitHub.

## Các lệnh Git đã sử dụng

- `git init`: Khởi tạo Local Repository.
- `git remote add origin <URL>`: Kết nối Local Repository với Remote Repository trên GitHub.
- `git add README.md`: Đưa file README.md vào Staging Area.
- `git commit -m "Add README.md file"`: Lưu thay đổi vào lịch sử Git với commit message.
- `git branch -M main`: Đặt tên nhánh hiện tại là main.
- `git push -u origin main`: Đẩy commit từ Local Repository lên Remote Repository trên GitHub.

## Quy trình
1. Tạo Repository mới trên GitHub.
2. Khởi tạo Local Repository bằng `git init`.
3. Kết nối Remote bằng `git remote add origin`.
4. Tạo và thêm README.md.
5. Commit thay đổi.
6. Push lên nhánh main.

## Repository GitHub
Sau khi tạo Repository, dán link GitHub vào đây:

https://github.com/USERNAME/my-new-project
